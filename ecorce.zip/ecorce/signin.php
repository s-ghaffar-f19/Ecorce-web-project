<?php
include 'buyer/includes/connection.php';
include 'seller/includes/connection.php';
if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
    if ($_SESSION['role'] == 1) {
        header("location: seller/index.php");
    } else {
        header("location: buyer/index.php");
    }
    
} else{
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $useremail = $_POST["loginEmail"];
    $password = $_POST["loginPassword"]; 
    
    $sql = "SELECT * FROM `users` WHERE `email` = '$useremail' OR `username` = '$useremail'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    if ($num == 1){
        while($row=mysqli_fetch_assoc($result)){
                        if (password_verify($password, $row['password'])){ 
                            if ($row['role'] == 1) {
                                $login = true;
                                session_start();
                                $_SESSION['loggedin'] = true;
                                $_SESSION['email'] = $useremail;
                                $_SESSION['username'] = $useremail;
                                $_SESSION['id'] = $row['id'];
                                $_SESSION['role'] = $row['role'];
                                $_SESSION['name'] = $row['firstname'] . " " . $row['lastname'];
                                header("location: seller/index.php");   
                            } else {
                                $login = true;
                                session_start();
                                $_SESSION['loggedin'] = true;
                                $_SESSION['email'] = $useremail;
                                $_SESSION['username'] = $useremail;
                                $_SESSION['id'] = $row['id'];
                                $_SESSION['name'] = $row['firstname'] . " " . $row['lastname'];
                                header("location: buyer/index.php");
                            }
                        } 
                        else{
                            $showError = "Please enter correct password";
                        }
                        
                    }
    } 
    else{
        $showError = "Please enter correct email or username";
    }
}
// echo $result2;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css" />
    <link rel="stylesheet" href="./css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />

    <title>Sign Up</title>
</head>

<body class="bg-light">
    <div>
        <?php require("buyer/includes/formHeader.php"); ?>
    </div>
    <div class="my-3 px-5 py-3 rounded bg-white width-v">
    <?php
        if($login){
        echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> You are logged in
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div> ';
        }
        if($showError){
        echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> '. $showError.'
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div> ';
        }
    ?>
        <div class="text-center">
            <h2>Sign-In</h2>
        </div>
        <div class="col-sm-12 mt-4 d-flex justify-content-center">
            <div>
                <form method="post">
                    <div class="mb-2">
                        <label for="loginEmail" class="form-label">Email / Username</label>
                        <input type="text" class="form-control" id="loginEmail" name="loginEmail"/>
                    </div>
                    <div class="mb-4">
                        <label for="loginPassword" class="form-label">Password</label>
                        <input type="password" class="form-control" id="loginPassword" name="loginPassword" />
                    </div>
                    <div class="text-center mb-2">
                        <button type="submit" class="col-6 btn btn-primary fw-bold">Login</button>
                    </div>
                    <div class="mb-3 mt-4 text-center text-success fw-secondary fst-italic">
                    <div class="d-flex align-items-center justify-content-between">
                    <hr class="hrw" /><span class="fst mx-2">New to ECORCE?</span><hr class="hrw" />
                    </div>    
                        <button class="btn btn-sm btn-warning mt-1"><a class="text-decoration-none fw-bold text-white" 
                                href="signup.php">Create a New Account</a></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div style="margin-top: 70px">
        <?php require("buyer/includes/formFooter.php"); ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js"
        integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/"
        crossorigin="anonymous"></script>
</body>

</html>