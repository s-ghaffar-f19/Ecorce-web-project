<?php
require("includes/connection.php");
require("includes/logincheck.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (isset( $_POST['snoEdit'])){
      // Update the record
      $product_name = $_POST['product_name']; 
      $product_price = $_POST['product_price']; 
      $product_desc = $_POST['product_desc']; 
      $product_desc = str_replace("<", "&lt;", $product_desc);
      $product_desc = str_replace(">", "&gt;", $product_desc); 
      $sno = $_POST['snoEdit']; 
    
      // Sql query to be executed
      $sql = "UPDATE `electronics_cat` SET `elect_category_name` = '$product_name' , `elect_category_price` = '$product_price', `elect_category_desc` = '$product_desc' WHERE `elect_category_id` = $sno";
      $result = mysqli_query($conn, $sql);
      if($result){
        $update = true;
    }
    else{
        echo "We could not update the record successfully";
    }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>ECORCE-Manage Items</title>
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/style.css" rel="stylesheet" media="all">

</head>

<body>
    <div class="page-wrapper">

        <?php include 'includes/mobileHeader.php'; ?>
        <?php include 'includes/menuSidebar.php'; ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <?php include 'includes/desktopHeader.php' ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">

                    <div class="col-lg-12">
                        <!-- DATA TABLE -->
                        <h3 class="title-5 m-b-35">data table</h3>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 table-hover">
                                <thead class="bg-dark">
                                    <tr>
                                        <th class="text-light">Sr#</th>
                                        <th class="text-light">name</th>
                                        <th class="text-light">description</th>
                                        <th class="text-light">date</th>
                                        <th class="text-light">price</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $sql = "SELECT * FROM electronics_cat";
                                        $result = mysqli_query($conn, $sql);
                                        $sno = 0;
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            $sno = $sno + 1;
                                            $pro_id = $row['elect_category_id'];
                                            $name = $row['elect_category_name'];
                                            $description = $row['elect_category_desc'];
                                            $price = $row['elect_category_price'];
                                            $time = $row['created'];
                                            echo '  <tr class="tr-shadow">
                                                        <td class="font-weight-bold align-middle">'. $sno . '</th>
                                                        <td><a class="text-success text-decoration-none font-weight-bold" 
                                                            href="/ecorce/buyer/commentlist.php?electcatid=' . $pro_id . '">'.$name.'</a></td>
                                                        <td class="desc">'.substr($description,4,200).'</td>
                                                        <td>'.$time.'</td>
                                                        <td><span class="badge badge-pill bg-secondary text-light px-3 py-2">'
                                                            .$price.'</span></td>
                                                        <td>
                                                            <div class="table-data-feature">
                                                                <button class="item edit" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                 <a href="edititem.php?pro_id='.$pro_id.'">
                                                                    <i class="zmdi zmdi-edit"></i></a>
                                                                </button>
                                                                <button class="item bg-danger" data-placement="top" title="Delete"
                                                                data-toggle="tooltip">
                                                                    <a href="deleteitem.php?pro_id='.$pro_id.'" class="text-light">
                                                                    <i class="zmdi zmdi-delete text-light"></i></a>
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr class="spacer"></tr>';
                                        }
                                    ?>
                                    
                                </tbody>
                            </table>
                                
                        </div>
                        <!-- END DATA TABLE -->
                    </div>

                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
    
</body>

</html>