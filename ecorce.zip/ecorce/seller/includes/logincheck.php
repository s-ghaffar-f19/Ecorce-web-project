<?php
if (!(isset($_SESSION['loggedin']) && ($_SESSION['loggedin']))) {
    header("location: /ecorce/signin.php");
}
if (!($_SESSION['role'] == 1)) {
    header("location: /ecorce/signin.php");
}
