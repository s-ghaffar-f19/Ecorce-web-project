<?php
require("includes/connection.php");
require("includes/logincheck.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>ECORCE-Dashboard</title>
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/style.css" rel="stylesheet" media="all">

</head>

<body>
    <div class="page-wrapper">

        <?php include 'includes/mobileHeader.php'; ?>
        <?php include 'includes/menuSidebar.php'; ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <?php include 'includes/desktopHeader.php' ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <h3 class="mb-3">Sold Products</h3>

                        <div class="row">

                            <!-- Sold Items -->
                            <div class="">
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Sr#</th>
                                                <th>Product</th>
                                                <th>Time</th>
                                                <th class="text-right">price</th>
                                                <th class="text-right">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sql = "SELECT * FROM cart";
                                            $result = mysqli_query($conn, $sql);
                                            $sno = 0;
                                            while ($row2 = mysqli_fetch_assoc($result)) {
                                                $pro_id = $row2['elect_category_id'];
                                                $sqlq = "SELECT * FROM electronics_cat WHERE elect_category_id = '$pro_id'";
                                                $res = mysqli_query($conn, $sqlq);
                                                $row = mysqli_fetch_assoc($res);
                                                $sno = $sno + 1;
                                                $pro_id = $row['elect_category_id'];
                                                $name = $row['elect_category_name'];
                                                $price = $row['elect_category_price'];
                                                $time = $row2['timestamp'];
                                                $status = $row2['status'];
                                                echo '  <tr>
                                                            <td class="font-weight-bold align-middle">'. $sno . '</th>
                                                            <td><a class="text-success text-decoration-none font-weight-bold" 
                                                                href="/ecorce/buyer/commentlist.php?electcatid=' . $pro_id . '">'.$name.'</a></td>
                                                            <td>'. $time . '</th>
                                                            <td><span class="badge badge-pill bg-secondary text-light px-3 py-2">'
                                                                .$price.'</span></td>
                                                            <td>'. $status . '</th>
                                                        </tr>';
                                            }
                                        ?>
                                        
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END Sold Items -->

                            <!-- Performance Table -->
                            <!-- <div class="performance col-lg-4">
                                <h3 class="title-3 m-b-30">performance</h3>
                                <div class="table-responsive">
                                    <table class="table table-performance table-hover">
                                        <tbody>
                                            <tr>
                                                <th>Order</th>
                                                <th>Rating</th>
                                            </tr>
                                            <tr>
                                                <td>Shipped on time</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Cancellation Rate</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Return Rate</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Positive Seller Rating</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Product Rating</td>
                                                <td>-</td>
                                            </tr> -->
                                            <!-- <tr>
                                                <td>Response Rate</td>
                                                <td>-</td>
                                            </tr> -->
                                            <!-- <tr>
                                                <td>Response Time (min)</td>
                                                <td>-</td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- End Performance Table -->

                        </div>

                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    
    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
