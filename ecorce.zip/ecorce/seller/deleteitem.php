<?php

require("includes/connection.php");
require("includes/logincheck.php");

if (isset($_GET['pro_id'])) {
    $pro_id = ($_GET['pro_id']);

    $query = "DELETE FROM electronics_cat WHERE elect_category_id='$pro_id'";
    $res = mysqli_query($conn, $query);
    header("location:manageitems.php");
}