<?php
require("includes/connection.php");
require("includes/logincheck.php");
$alert = false;
$error = false;
$method = $_SERVER['REQUEST_METHOD'];
        if($method=='POST'){
            //Insert into products
            $product_name = $_POST['product_name']; 
            $product_price = $_POST['product_price']; 
            $product_desc = $_POST['product_desc']; 
            $product_desc = str_replace("<", "&lt;", $product_desc);
            $product_desc = str_replace(">", "&gt;", $product_desc); 
            $sno = $_POST['id']; 
            if ($product_name == "" || $product_price == "" || $product_desc == "" || $product_name == null || $product_price == null || $product_desc == null) {
                $error = true;
            } else {
                $sql = "INSERT INTO `electronics_cat` ( `elect_category_name`, `elect_category_price`, `elect_category_desc`) VALUES
                ('$product_name', '$product_price', '$product_desc')";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $alert = true;
                } else {
                    $error = true;
                }
            }
            
        }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>ECORCE-Add Item</title>
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/style.css" rel="stylesheet" media="all">

</head>

<body>
    <div class="page-wrapper">

        <?php include 'includes/mobileHeader.php'; ?>
        <?php include 'includes/menuSidebar.php'; ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <?php include 'includes/desktopHeader.php' ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <!-- alert message -->
                        <?php
                        if ($alert) {
                            echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Product Added Successfully!</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>';
                        } if($error) {
                            echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Uploading Product Failed!</strong>Please check all fields!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>';
                        }                        
                        ?>
                        <!-- end alert message -->

                        <div>
                            <div class="card">
                                <div class="card-header">
                                    <strong>Add New Item</strong>
                                </div>
                                <form method="post">
                                    <div class="card-body card-block">
                                        <div class="form-group">
                                            <label for="inputIsValid" class=" form-control-label">Product Name</label>
                                            <input type="text" id="inputIsValid" class="form-control" name="product_name" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputIsInvalid" class=" form-control-label">Product Price</label>
                                            <input type="number" id="inputIsInvalid" class="form-control" name="product_price" required>
                                        </div>
                                        <div class="form-group mb-4">
                                            <label for="inputIsInvalid" class=" form-control-label">Product Description</label>
                                            <textarea id="inputIsInvalid" cols="30" rows="10" name="product_desc" class="form-control" required>
                                            </textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>