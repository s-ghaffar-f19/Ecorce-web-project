<?php

require("includes/connection.php");
require("includes/logincheck.php");

$error = false;
$pro_id = ($_GET['pro_id']);

    $sqlq = "SELECT * FROM `electronics_cat` WHERE `elect_category_id` = $pro_id";
    $res = mysqli_query($conn, $sqlq);
    $row = mysqli_fetch_assoc($res);
    $name = $row['elect_category_name'];
    $description = $row['elect_category_desc'];
    $price = $row['elect_category_price'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $product_name = ($_POST['product_name']);
    $product_desc = ($_POST['product_desc']);
    $product_price = ($_POST['product_price']);

    $sql = "UPDATE `electronics_cat` SET `elect_category_name` = '$product_name' , `elect_category_price` = '$product_price', `elect_category_desc` = '$product_desc' WHERE `elect_category_id` = $pro_id";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("location:manageitems.php");
    } else {
        $error = true;
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title Page-->
    <title>ECORCE-Edit Items</title>
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/style.css" rel="stylesheet" media="all">
</head>
<body>
<div class="page-wrapper">

<?php include 'includes/mobileHeader.php'; ?>
<?php include 'includes/menuSidebar.php'; ?>

<!-- PAGE CONTAINER-->
<div class="page-container">
    <?php include 'includes/desktopHeader.php' ?>

    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <?php
                    if($error) {
                        echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Updating Product Failed!</strong>Please check all fields!
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                        </div>';
                    }
                ?>
    <div class="card">
        <div class="card-header">
            <strong>Add New Item</strong>
        </div>
        <form method="post">
            <div class="card-body card-block">
                <input type="hidden" name="snoEdit" id="snoEdit">
                <div class="form-group">
                    <label for="product_name" class=" form-control-label">Product Name</label>
                    <input type="text" id="product_name" value="<?php echo $name ?>" class="form-control" name="product_name" required>
                </div>
                <div class="form-group">
                    <label for="product_price" class=" form-control-label">Product Price</label>
                    <input type="number" id="product_price" value="<?php echo $price ?>" class="form-control" name="product_price" required>
                </div>
                <div class="form-group mb-4">
                    <label for="product_desc" class=" form-control-label">Product Description</label>
                    <textarea id="product_desc" cols="30" rows="10" name="product_desc" class="form-control" required>
                    <?php echo $description ?></textarea>
                </div>
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-dot-circle-o"></i> Submit
                </button>
                <button type="reset" class="btn btn-danger">
                    <i class="fa fa-ban"></i> Reset
                </button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
    
</body>
</html>