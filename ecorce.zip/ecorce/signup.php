<?php
include 'buyer/includes/connection.php';
include 'seller/includes/connection.php';
if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
    if ($_SESSION['role'] == 1) {
        header("location: seller/index.php");
    } else {
        header("location: buyer/index.php");
    }
    
} else{
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    $first_name = $_POST["firstName"];
    $last_name = $_POST["lastName"];
    $user_name = $_POST["signupUserName"];
    $user_email = $_POST["signupEmail"];
    $pass = $_POST["signupPassword"];
    $cpass = $_POST["cSignupPassword"];
    $user_contact = $_POST["signupContact"];
    $user_city = $_POST["signupCity"];
    $user_address = $_POST["signupAddress"];

    $existSql = "SELECT * FROM `users` WHERE email = '$user_email' OR username = '$user_name'";
    $result = mysqli_query($conn, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        $showError = "User Already Exists";
    }
    elseif ($first_name == "" || $last_name == "" || $user_name == "" || $user_email == "" || $pass == "" || $user_contact =="" || $user_city == "" || $user_address == "") {
        $showError = "Please check all fields!";
    }else{
        if(($pass == $cpass)){
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $sql = "INSERT INTO `users` (`username`, `firstname`, `lastname`, `email`, `contact`, `password`, `city`, `address`) VALUES 
            ('$user_name', '$first_name', '$last_name', '$user_email', '$user_contact', '$hash', '$user_city', '$user_address')";
            $result = mysqli_query($conn, $sql);
            if ($result){
                $showAlert = true;
                header("Location: signin.php?signupsuccess=true");
            }
        }
        else{
            $showError = "Passwords do not match";
        }
        // header("Location: signin.php?signupsuccess=true");
    }

    
    
}

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css" />
    <link rel="stylesheet" href="./css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />

    <title>Sign Up</title>
</head>

<body class="bg-light">
    <div>
        <?php require("buyer/includes/formHeader.php"); ?>
    </div>
    
    <div class="my-3 px-5 py-3 rounded bg-white width-v">
    <?php
        if($showAlert){
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> Your account is now created and you can login.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
            }
            if($showError){
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> '. $showError.'
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
            }
    ?>
        <div class="text-center">
            <h2>Create Account</h2>
            <p class="text-center text-warning fw-bold mb-4">Please fill the form to create an account.</p>
        </div>
        <div class="col-sm-12  d-flex justify-content-center">
            <div>
                
                <form method="post">
                    <div class="d-flex flex-row">
                        <div class="mb-3 me-3">
                            <label for="firstName" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required />
                        </div>
                        <div class="mb-3">
                            <label for="lastName" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required/>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="signupUserName" class="form-label">Username</label>
                        <input type="text" class="form-control" id="signupUserName" name="signupUserName" required/>
                    </div>
                    <div class="mb-3">
                        <label for="signupEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" id="signupEmail" name="signupEmail" required/>
                    </div>
                    <div class="d-flex flex-row">
                        <div class="mb-3 me-3">
                            <label for="signupPassword" class="form-label">Password</label>
                            <input type="password" class="form-control" id="signupPassword" name="signupPassword" required/>
                        </div>
                        <div class="mb-3">
                            <label for="cSignupPassword" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="cSignupPassword" name="cSignupPassword" required/>
                        </div>
                    </div>
                    <div class="d-flex flex-row">
                        <div class="mb-3 me-3">
                            <label for="signupContact" class="form-label">Contact</label>
                            <input type="number" class="form-control" id="signupContact" name="signupContact" required/>
                        </div>
                        <div class="mb-3">
                            <label for="signupCity" class="form-label">City</label>
                            <input type="text" class="form-control" id="signupCity" name="signupCity" required/>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="signupAddress" class="form-label">Address</label>
                        <textarea name="signupAddress" id="signupAddress" class="form-control" cols="30" rows="3" required>
                        </textarea>
                    </div>
                    <div class="text-center mb-2">
                        <button type="submit" class="col-6 btn btn-primary fw-bold">Create Account</button>
                    </div>
                    <div class="mb-3 text-center text-success fw-secondary fst-italic">
                    <div class="d-flex align-items-center justify-content-between">
                    <hr class="hrw" /><span class="fst">Already have an account?</span><hr class="hrw" />
                    </div>    
                        <button type="submit" class="btn btn-sm btn-warning mt-1"><a class="text-decoration-none fw-bold text-white" 
                                href="">Login Here</a></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="" style="margin-top: 70px">
        <?php require("buyer/includes/formFooter.php"); ?>
    </div>

    <script>
        $(document).ready(function() {
            $(".toast").toast('show');
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js"
        integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/"
        crossorigin="anonymous"></script>
</body>

</html>