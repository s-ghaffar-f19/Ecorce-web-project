<?php
require("includes/connection.php");
if (!(isset($_SESSION['loggedin']) && ($_SESSION['loggedin']))) {
    header("location: /ecorce/signin.php");
}else{
    if (isset($_GET['cmntid']) && ($_GET['prodid'])) {
        $prodid = ($_GET['prodid']);
        $item_id = $_GET["cmntid"];
        $user_id = $_SESSION['id'];

        $query = "DELETE FROM commentlist WHERE comment_id='$item_id' AND comment_by='$user_id' ";
        $res = mysqli_query($conn, $query);
        header("location:commentlist.php?electcatid=$prodid");
    }
}
?>