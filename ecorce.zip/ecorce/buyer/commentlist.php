<?php include 'includes/connection.php';?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />
    <title>ECORCE - Product Details</title>
</head>
<style>
    #more {
        display: none;
    }
</style>

<body>
    <?php include 'includes/header.php';?>

    <div class="card m-5 p-5">
        <div class="row g-0">
            <div class="col-md-6 text-center">
                <?php 
        $id = $_GET['electcatid'];
        $sql0 = "SELECT * FROM `electronics_cat` WHERE elect_category_id=$id"; 
        $result0 = $conn->query($sql0);
        $row = mysqli_fetch_assoc($result0);
        $id = $row['elect_category_id'];
        $cat = $row['elect_category_name']; 
        $price = $row['elect_category_price']; 
        $details = $row['elect_category_desc']; 
        echo '
        <img src="images/' . $id . '.jpg" width="350px" height="500px" class="img-fluid rounded-start" alt="...">
        </div>
        <div class="col-md-6">
        <div class="card-body">
            <h4 class="card-title text-success">'. $cat .'</h4>
            <h5 class="card-title text-secondary mb-4">Rs. '. $price .'/- only</h5>
            <p class="card-text">'. $details .'
            <button class="btn btn-sm text-primary" onclick="myFunction()" id="myBtn">Read more</button></p>
        </div>';
        ?>
        </div>
    </div>
    </div>
    <?php
        
        $method = $_SERVER['REQUEST_METHOD'];
        if($method=='POST'){
            //Insert into comment db
            $comment = $_POST['comment']; 
            $comment = str_replace("<", "&lt;", $comment);
            $comment = str_replace(">", "&gt;", $comment); 
            $sno = $_POST['id']; 
            $sql = "INSERT INTO `commentlist` ( `comment_content`, `elect_category_id`, `comment_by`, `timestamp`) VALUES
             ('$comment', '$id', '$sno', current_timestamp())";
            $result = mysqli_query($conn, $sql);
            
        }
    
        if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){ 
            echo '<div class="container">
                    <h1 class="py-2">Post a Comment</h1> 
                    <form action= "'. $_SERVER['REQUEST_URI'] . '" method="post"> 
                        <div class="form-group">
                            <label for="comment">Type your comment:</label>
                            <textarea class="form-control my-2" id="comment" name="comment" rows="3"></textarea>
                            <input type="hidden" name="id" value="'. $_SESSION["id"]. '">
                        </div>
                        <button type="submit" class="my-2 btn btn-success">Post Comment</button>
                    </form> 
                </div>';
        }
        else{
            echo '<div class="container">
            <h1 class="py-2">Post a Comment</h1> 
            <p class="lead">You are not logged in. Please login to be able to post comments.</p>
            </div>
            ';
        }
    ?>



    <div class="container my-5">
        <h1 class="py-2">Comments</h1>
        <?php
    $id = $_GET['electcatid'];
    $sql = "SELECT * FROM `commentlist` WHERE elect_category_id=$id ORDER BY timestamp DESC"; 
    $result = $conn->query($sql);
    $noResult = true;
    while($row = mysqli_fetch_assoc($result)){
        $noResult = false;
        $cmntid = $row['comment_id'];
        $content = $row['comment_content']; 
        $comment_time = $row['timestamp']; 
        $comment_user_id = $row['comment_by']; 

        $sql2 = "SELECT * FROM `users` WHERE id='$comment_user_id'";
        $result2 = $conn->query($sql2);
        $row2 = mysqli_fetch_assoc($result2);

        
        echo '<div class="media my-3">
            <div class="media-body cmnt-title">
                <div class="float-start d-flex align-items-center">
                    <img src="images/avatar.png" width="54px" alt="..." class="mr-3" />
                    <h6 class="fw-bold text-warning my-0">&nbsp;&nbsp;&nbsp;'. $row2['firstname'] . " " . $row2['lastname'] .'</h6>
                </div>
                <div class="float-end">
                    <h6 class="my-0 float-end"> &nbsp;&nbsp;&nbsp;'. $comment_time. '</h6>
                </div>
                </div>
                <P class="ms-5"> &nbsp;&nbsp;&nbsp; '. $content . '</p>';
                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true) {
                    $userid = $_SESSION['id'];
                    if ($comment_user_id == $userid) {   
                        echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href='commentDelete.php?cmntid=".$cmntid."&prodid=".$id."' 
                        class='remove_item_link fss text-danger ms-5 text-decoration-none'> Delete </a>";
                    }
                    echo '</div> <hr />';
                }
                else {
                    echo '</div> <hr />';
                }
        

        }
        
        if($noResult){
            echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="display-4">No Comments Found</p>
                        <p class="lead"> Be the first person to comment</p>
                    </div>
                 </div> ';
        }
    
    ?>

                </div>

                <script>
                    function myFunction() {
                        var dots = document.getElementById("dots");
                        var moreText = document.getElementById("more");
                        var btnText = document.getElementById("myBtn");

                        if (dots.style.display === "none") {
                            dots.style.display = "inline";
                            btnText.innerHTML = "Read more";
                            moreText.style.display = "none";
                        } else {
                            dots.style.display = "none";
                            btnText.innerHTML = "Read less";
                            moreText.style.display = "inline";
                        }
                    }
                </script>



                <?php include 'includes/footer.php';?>
                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
                    integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp"
                    crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js"
                    integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/"
                    crossorigin="anonymous"></script>
</body>

</html>