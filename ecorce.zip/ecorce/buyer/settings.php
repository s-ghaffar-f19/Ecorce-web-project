<?php
require("includes/connection.php");
if (!(isset($_SESSION['loggedin']) && ($_SESSION['loggedin']))) {
    header("location: /ecorce/signin.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" 
        crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" 
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" 
        crossorigin="anonymous" />
    <title>Market Place</title>
    <style>
            #minHeight{
                min-height: 50vh;
            }
        </style>
</head>
<body>
    <div>
        <?php require("includes/header.php"); ?>
    </div>
    <div class="my-3 container">
        <h2>Settings</h2>
    </div>
    <hr />
    <div class="my-5 container" id="minHeight">

        <?php
            if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
                $id = $_SESSION['id'];
                $sql="SELECT * FROM `users` WHERE id = $id";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($rows = mysqli_fetch_assoc($result)) {
                        $name = $rows['firstname'] . " " . $rows['lastname'];
                        $username = $rows['username'];
                        $email = $rows['email'];
                        $contact = $rows['contact'];
                        $city = $rows['city'];
                        $address = $rows['address'];
                      echo '<table class="table table-borderless table-striped">
                                <tbody>
                                    <tr>
                                    <th scope="row">Username:</th>
                                    <td>'.$username.'</td>
                                    </tr>
                                    <tr>
                                    <th scope="row">Name:</th>
                                    <td>'.$name.'</td>
                                    </tr>
                                    <tr>
                                    <th scope="row">Email:</th>
                                    <td>'.$email.'</td>
                                    </tr>
                                    <tr>
                                    <th scope="row">Contact:</th>
                                    <td>'.$contact.'</td>
                                    </tr>
                                    <tr>
                                    <th scope="row">City:</th>
                                    <td>'.$city.'</td>
                                    </tr>
                                    <tr>
                                    <th scope="row">Address:</th>
                                    <td>'.$address.'</td>
                                    </tr>
                                </tbody>
                            </table>';
                    }
                }
            }

        ?>

    </div>
    <div>
        <?php require("includes/footer.php"); ?>
    </div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>
</html>