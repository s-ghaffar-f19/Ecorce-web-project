<?php
require("includes/connection.php");
if (isset($_GET['id'])) {
    $item_id = $_GET['id'];
    $user_id = $_SESSION['id'];
    $query = "INSERT INTO cart(user_id, elect_category_id, status) VALUES('$user_id', '$item_id', 'Added to cart')";
    mysqli_query($conn, $query);
    header('location: index.php');
}
?>
