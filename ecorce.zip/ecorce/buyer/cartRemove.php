<?php
require("includes/connection.php");
if (isset($_GET['id'])) {
    $item_id = $_GET["id"];
    $user_id = $_SESSION['id'];

    $query = "DELETE FROM cart WHERE elect_category_id='$item_id' AND user_id='$user_id' ";
    $res = mysqli_query($conn, $query);
    header("location:cart.php");
}
?>