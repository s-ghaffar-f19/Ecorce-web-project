<?php require("includes/connection.php");  ?>

<button class="btn btn-secondary m-0 p-0 px-1 me-2 py-1" type="button" data-bs-toggle="offcanvas" 
data-bs-target="#sideMenu" aria-controls="sideMenu">
<span class="navbar-toggler-icon p-0"></span>
</button>

    <?php

    if ((isset($_SESSION['loggedin']) && ($_SESSION['loggedin']))) {
      echo'
      <div class="w-h offcanvas offcanvas-start" tabindex="-1" id="sideMenu" aria-labelledby="sideMenuLabel">
      <div class="offcanvas-header text-center p-2 bg-dark">
      <img src="images/avatar.png" width="35px" alt="..." class="" />
      <h4 class="offcanvas-title text-light" id="sideMenuLabel">Hello, <span class="text-warning">'. ($_SESSION['name']) .'</span></h4>
      <button type="button" class="m-0 btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>';
    } else {
      echo'
      <div class="w-h offcanvas offcanvas-start" tabindex="-1" id="sideMenu" aria-labelledby="sideMenuLabel">
      <div class="offcanvas-header text-center bg-warning">
      <h4 class="offcanvas-title text-white" id="sideMenuLabel">Hello, Sign in</h4>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>';
    }
    
    ?> 
    <div class="offcanvas-body">
      <ul class="nav flex-column">
        <li class="nav-item ms-2 mb-2"><a href="index.php" class="nav-link p-2 sm-hvr text-warning fw-bold">Home</a></li>
        <?php

            if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
              $id = $_SESSION['id'];
                    $sql = "SELECT * FROM cart WHERE user_id = $id";
                    $result = mysqli_query($conn, $sql);
                    $rows = mysqli_num_rows($result);  
              echo'<li class="nav-item mb-2"><a class="position-relative nav-link sm-hvr text-warning fw-bold" href="cart.php?cartId='
                  .$_SESSION['id'].'">Cart <i class="fas fa-shopping-cart">
                  <span class="position-absolute top-50 end-0 translate-middle badge rounded-pill bg-primary">
                    '. $rows .'
                  </span></i></a>
                </li>';
            }
            else{
              echo'<li class="nav-item me-3">
              <!-- Button trigger modal -->
                <a class="nav-link text-warning sm-hvr fw-bold" href="cart.php?id=" data-bs-toggle="modal" data-bs-target="#cartModal">
                Cart <i class="fas fa-shopping-cart"></i></a>
              </li>

              <!-- Modal -->
              <div class="modal fade text-center" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
                <div class="modal-dialog text-center p-5">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title text-warning" id="cartModalLabel">Login Required</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body m-2">
                      <span class="text-secondary">Please login or create an account to continue!</span><br /><br />
                      <button type="button" class="btn btn-sm btn-warning">
                      <a class="text-light text-decoration-none fw-bold" href="/ecorce/signin.php">Login</a></button>
                      <button type="button" class="btn btn-sm btn-warning">
                      <a class="text-light fw-bold text-decoration-none" href="/ecorce/signup.php">Signup</a></button>
                    </div>
                  </div>
                </div>
              </div>';
            }

        ?>
        <li class="nav-item ms-2 mb-2"><a href="contact.php" class="nav-link p-2 sm-hvr text-warning fw-bold">Contact us</a></li>
        <li class="nav-item ms-2 mb-2"><a href="privacyPolicy.php" class="nav-link p-2 sm-hvr text-warning fw-bold">Privacy Policy</a></li>
        <li class="nav-item ms-2 mb-2"><a href="about.php" class="nav-link p-2 sm-hvr text-warning fw-bold">About</a></li>
        <li id="minHeight"></li><hr />

        <?php

            if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
              echo '
              <li class="nav-item text-center">
                <div class="dropup btn-group sm-w">
                <a class="position-relative nav-link dropdown-toggle text-warning btn sm-hvr fw-bold" href="#" id="sideMenuLink" 
                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                '. ($_SESSION['name']) .'
                <span class="position-absolute top-40 start-1 translate-middle p-1 bg-success border border-light rounded-circle">
                </a>
                <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="sideMenuLink">
                  <li><a class="dropdown-item" href="settings.php">Settings</a></li>
                  <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
                </div>
              </li>
              ';
            } else {
              echo '<li class="nav-item me-3">
                <a class="nav-link text-warning sm-hvr fw-bold" href="/ecorce/signin.php">Login</a>
              </li>';
            }

        ?>
      </ul>
    </div>
</div>