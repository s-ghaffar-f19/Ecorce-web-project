<div class="text-center mt-3">
    <a class="text-decoration-none text-dark fw-bold" href="index.php"><h1>ECO<span class="text-warning">RCE</span></h1></a>
</div>