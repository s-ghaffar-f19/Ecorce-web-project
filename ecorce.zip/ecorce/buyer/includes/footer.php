    <div class="bg-dark text-light">
    <div class="container">
        <footer class="pt-5 pb-1 text-center">
        <div class="d-flex flex-row row justify-content-center text-center mr-0">
                <div class="col-sm-3">
                    <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="index.php" class="nav-link p-0 text-light">Home</a></li>
                    <li class="nav-item mb-2"><a href="cart.php" class="nav-link p-0 text-light">Cart</a></li>
                    <li class="nav-item mb-2"><a href="/ecorce/signin.php" class="nav-link p-0 text-light">Login</a></li>
                    <li class="nav-item mb-2"><a href="/ecorce/signup.php" class="nav-link p-0 text-light">Signup</a></li>
                    <li class="nav-item mb-2"><a href="about.php" class="nav-link p-0 text-light">About</a></li>
                    </ul>
                </div>

                <div class="col-sm-3">
                    <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="contact.php" class="nav-link p-0 text-light">Contact us</a></li>
                    <li class="nav-item mb-2"><a href="privacyPolicy.php" class="nav-link p-0 text-light">Privacy Policy</a></li>
                    <li class="nav-item mb-2"><a href="https://www.facebook.com" class="nav-link p-0 text-light">Facebook</a></li>
                    <li class="nav-item mb-2"><a href="https://www.instagram.com" class="nav-link p-0 text-light">Instagram</a></li>
                    <li class="nav-item mb-2"><a href="https://www.twitter.com" class="nav-link p-0 text-light">Twitter</a></li>
                    </ul>
                </div>

            <div class="col-sm-6">
                <form>
                <h5>Subscribe to our newsletter</h5>
                <p>We will update you about our latest products.</p>
                <div class="d-flex w-100">
                    <label for="newsletter1" class="visually-hidden">Email address</label>
                    <input id="newsletter1" type="text" class="form-control" placeholder="Email address">
                    <button class="btn btn-warning rounded-end ml-n" type="button">Subscribe</button>
                </div>
                </form>
            </div>
            </div>

            <div class="d-flex justify-content-between pt-4 my-4 border-top">
            <p>&copy; 2021 ecorce, Inc. All rights reserved.</p>
            <ul class="list-unstyled d-flex">
                <li class="ms-3">
                    <a class="link-light text-info" href="#"><i class="fab fa-2x fa-twitter"></i></a>
                </li>
                <li class="ms-3">
                    <a class="link-dark text-danger" href="#"><i class=" fab fa-2x fa-instagram"></i></a>
                </li>
                <li class="ms-3">
                    <a class="link-dark text-primary" href="#"><i class="fab fa-2x fa-facebook"></i></a>
                </li>
            </ul>
            </div>
        </footer>
    </div>
    </div>
