<?php require("includes/connection.php");  ?>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand ml-hdr fs-4 fw-bold" href="index.php">ECO<span class="text-warning">RCE</span></a>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <form class="d-flex mb-2 ml-hdr mb-lg-0 me-auto col-9" method="get" action="search.php">
          <input class="form-control" type="search" placeholder="Search" aria-label="Search" name="search" />
          <button class="btn btn-sm bg-warning text-dark fw-bold rounded-end ml-n" type="submit">Search</button>
        </form>
        <ul class="navbar-nav me-5">
          <?php

            if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
              echo '
              <li class="nav-item dropdown me-3">
                <a class="position-relative nav-link dropdown-toggle text-white fw-bold" href="#" id="navbarDarkDropdownMenuLink" 
                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                '. ($_SESSION['name']) .'
                <span class="position-absolute top-40 start-1 translate-middle p-1 bg-success border border-light rounded-circle">
                </a>
                <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                  <li><a class="dropdown-item" href="settings.php">Settings</a></li>
                  <li><a class="dropdown-item" href="/ecorce/logout.php">Logout</a></li>
                </ul>
              </li>
              ';
            } else {
              echo '<li class="nav-item me-3">
                <a class="nav-link text-light fw-bold" href="/ecorce/signin.php">Login</a>
              </li>';
            }
            if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
              $id = $_SESSION['id'];
                    $sql = "SELECT * FROM cart WHERE user_id = $id AND status = 'Added to cart'";
                    $result = mysqli_query($conn, $sql);
                    $rows = mysqli_num_rows($result);  
              echo'<li class="nav-item me-3">
                  <a class="position-relative nav-link text-warning fw-bold" href="cart.php?cartId='
                  .$_SESSION['id'].'">Cart <i class="fas fa-shopping-cart">
                  <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">
                    '. $rows .'
                  </span></i></a>
                </li>';
            }
            else{
              echo'<li class="nav-item me-3">
              <!-- Button trigger modal -->
                <a class="nav-link text-warning fw-bold" href="cart.php?id=" data-bs-toggle="modal" data-bs-target="#cartModal">
                Cart <i class="fas fa-shopping-cart"></i></a>
              </li>

              <!-- Modal -->
              <div class="modal fade text-center" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
                <div class="modal-dialog text-center p-5">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title text-warning" id="cartModalLabel">Login Required</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body m-2">
                      <span class="text-secondary">Please login or create an account to continue!</span><br /><br />
                      <button type="button" class="btn btn-sm btn-warning">
                      <a class="text-light text-decoration-none fw-bold" href="/ecorce/signin.php">Login</a></button>
                      <button type="button" class="btn btn-sm btn-warning">
                      <a class="text-light fw-bold text-decoration-none" href="/ecorce/signup.php">Signup</a></button>
                    </div>
                  </div>
                </div>
              </div>';
            }
          ?>
        </ul>
      </div>
    </div>
  </nav>
    <nav class="navbar navbar-expand-xxxl navbar-dark bg-secondary px-3 my-0 py-0 pb-1">
        <div>
            <ul class="list-inline my-0 py-0">
                <li class="list-inline-item">
                    <div class="d-flex flex-row m-0 p-0 pt-1">
                    <div>
                        <?php require("includes/sideMenu.php"); ?>
                    </div>
                    <div>
                        <form class="d-flex mb-2 mb-lg-0">
                            <input class="formhidn form-control" type="search" placeholder="Search" aria-label="Search" />
                            <button class="formhidn btn btn-sm bg-warning text-dark fw-bold rounded-end ml-n" type="submit">Search</button>
                        </form>
                    </div>
                    </div>
                </li>
                <li class="hidn list-inline-item">
                  <a class="hidn text-decoration-none text-light" href="contact.php">Customer Service</a>
                </li>
                <li class="hidn list-inline-item">
                    <a class="hidn text-decoration-none text-light" href="contact.php">Contact</a>
                </li>
                <li class="hidn list-inline-item">
                    <a class="hidn text-decoration-none text-light" href="about.php">About</a>
                </li>
            </ul>
        </div>
        <div class="hidn">
            <a class="hidn text-decoration-none text-light" href="">ecorce's response to COVID-19</a>
        </div>
    </nav>
