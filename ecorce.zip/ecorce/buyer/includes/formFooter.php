
<div class="d-flex justify-content-between pt-4 mx-5 border-top">
            <p>&copy; <?php echo date("Y")?> ECORCE, Inc. All rights reserved.</p>
            <ul class="list-unstyled d-flex">
                <li class="ms-3">
                    <a class="link-light text-info" href="https://www.twitter.com"><i class="fab fa-2x fa-twitter"></i></a>
                </li>
                <li class="ms-3">
                    <a class="link-dark text-danger" href="https://www.instagram.com"><i class=" fab fa-2x fa-instagram"></i></a>
                </li>
                <li class="ms-3">
                    <a class="link-dark text-primary" href="https://www.facebook.com"><i class="bg-light fab fa-2x fa-facebook"></i></a>
                </li>
            </ul>
            </div>