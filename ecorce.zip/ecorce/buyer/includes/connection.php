<?php

    // $con = new mysqli('localhost', 'root', '', 'ecorce');
    // if ($con -> connect_error) {
    //     echo "Connection Failed <br />" . $con;
    // }

    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "ecorcedb";

    $conn = mysqli_connect($server, $username, $password, $database);
    if (!$conn){
    //     echo "success";
    // }
    // else{
        die("Error". mysqli_connect_error());
    }
    if(!isset($_SESSION)){
        session_start();
      }

    // $con = mysqli_connect("localhost", "root", "", "storesss") or die(mysqli_error($con));
    // if(!isset($_SESSION)){
    //   session_start();
    // }
?>