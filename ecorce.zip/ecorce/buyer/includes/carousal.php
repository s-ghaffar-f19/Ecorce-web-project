<div id="changeSlideBtn" class="carousel slide carousel-fade" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/image1.png" class="carousel-h d-block w-100" alt="">
        </div>
        <div class="carousel-item">
            <img src="images/image2.jpg" class="carousel-h d-block w-100" alt="">
        </div>
        <div class="carousel-item">
            <img src="images/image3.jpg" class="carousel-h d-block w-100" alt="">
        </div>
    </div>

<button class="carousel-control-prev" type="button" data-bs-target="#changeSlideBtn" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
</button>
<button class="carousel-control-next" type="button" data-bs-target="#changeSlideBtn" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
</button>
</div>