<?php
    require("includes/connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" 
        crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" 
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" 
        crossorigin="anonymous" />
    <title>Market Place</title>
</head>
<body class="bg-aids">
    <div>
        <?php require("includes/header.php"); ?>
    <div class="container my-5">
        <h2 class="text-success">Who we are?</h2>
        <p class="text-justify">Lorem ipsumsint necessitatibus? Consequatur architecto corrupti pariatur doloremque quas vitae
             est totam quae eius maxime et temporibus nisi aut voluptas harum asperiores nostrum tempora adipisci, porro odit
              rem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, adipisci consequatur. Numquam non earum 
              provident quidem iusto. Iure quam beatae nobis eveniet totam impedit iste. Eligendi beatae dolore nam
               voluptatibus? temporibus nisi aut voluptas harum asperiores nostrum tempora adipisci, porro odit
              rem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, adipisci consequatur. Numquam non earum 
              provident quidem iusto. Iure quam beatae nobis eveniet totam impedit iste. Eligendi beatae dolore nam
               voluptatibus?
        </p>
    </div>
    <div class="container my-5">
        <h2 class="text-success text-center mb-3">Team Members</h2>
        <div class="row text-center">
            <div class="col-sm-4">
                <div class="card">
                <div class="card-body">
                    <h4 class="card-title text-primary">Fezan Ali</h4>
                    <p class="fw-bold text-secondary">
                        <span class="card-text">BS Software Engineering - BSSE</span><br />
                        <span class="card-text">Web & Android Developer</span><br />
                        <span class="card-text">Graphics Designer</span>
                    </p>
                    <a href="https://www.facebook.com/fezanalij" target="_blank" 
                    class="btn btn-sm btn-warning text-light fw-bold">Portfolio</a>
                </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card">
                <div class="card-body">
                    <h4 class="card-title text-primary">Gul Sher</h4>
                    <p class="fw-bold text-secondary">
                        <span class="card-text">BS Software Engineering - BSSE</span><br />
                        <span class="card-text">Web & Android Developer</span><br />
                        <span class="card-text">&nbsp;</span>
                    </p>
                    <a href="https://www.facebook.com/" target="_blank" 
                    class="btn btn-sm btn-warning text-light fw-bold">Portfolio</a>
                </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card">
                <div class="card-body">
                    <h4 class="card-title text-primary">Talib Khokhar(Team Leader)</h4>
                    <p class="fw-bold text-secondary">
                        <span class="card-text">BS Software Engineering - BSSE</span><br />
                        <span class="card-text">Web & Android Developer</span><br />
                        <span class="card-text">&nbsp;</span>
                    </p>
                    <a href="https://www.facebook.com/" target="_blank" 
                    class="btn btn-sm btn-warning text-light fw-bold">Portfolio</a>
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-5">
    <h2 class="text-success">Our Services</h2>
        <p class="text-justify">Lorem ipsumsint necessitatibus? Consequatur architecto corrupti pariatur doloremque quas vitae
             est totam quae eius maxime et temporibus nisi aut voluptas harum asperiores nostrum tempora adipisci, porro odit
              rem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, adipisci consequatur. Numquam non earum 
              provident quidem iusto. Iure quam beatae nobis eveniet totam impedit iste. Eligendi beatae dolore nam
               voluptatibus? temporibus nisi aut voluptas harum asperiores nostrum tempora adipisci, porro odit
              rem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, adipisci consequatur. Numquam non earum 
              provident quidem iusto. Iure quam beatae nobis eveniet totam impedit iste. Eligendi beatae dolore nam
               voluptatibus?
        </p>
    </div>
    <div>
        <?php require("includes/footer.php"); ?>
    </div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>
</html>