<?php

    require("includes/connection.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" 
        crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" 
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" 
        crossorigin="anonymous" />
    <title>Market Place</title>
</head>
<body class="bg-aids">
    <div>
        <?php require("includes/header.php"); ?>
    <div class="container my-5">
        <h2 class="text-success">What is our policy?</h2>
        <p class="text-justify">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Temporibus nobis, nulla quam optio natus incidunt quas voluptatem inventore repellendus cum, architecto suscipit tempore molestias officiis. Earum aliquam obcaecati asperiores repudiandae provident nobis eaque eius. Facere, beatae. Sint dolorem temporibus quasi voluptate ullam minus reprehenderit quos omnis nobis, magni repudiandae veniam iure nemo magnam obcaecati corrupti maiores qui fugiat dicta dolorum quaerat. Officiis assumenda culpa labore id natus non repellat illo fugit dolore, delectus quae nobis tempore ipsam aut, error aliquam quo ad suscipit! Laudantium incidunt praesentium eveniet inventore similique ut ipsa. Accusantium eius, ullam architecto alias numquam, necessitatibus saepe rem ipsum voluptates esse sequi? Voluptas, impedit nihil error in sed aperiam ad illum id libero architecto cumque. Aliquid consequuntur a enim magni laborum ipsa modi porro impedit debitis illum laboriosam autem, deleniti ipsam necessitatibus sapiente commodi. Totam, dignissimos. Mollitia praesentium ea distinctio? Sequi impedit est officiis velit quidem aut ipsam numquam dignissimos ab excepturi aspernatur iusto vel ipsa, voluptates tempore officia ad reiciendis eligendi dolorum sit assumenda recusandae sed facilis voluptatibus! Eveniet, quia et. Neque culpa quia velit eos distinctio. Id, harum est esse labore veniam doloribus consectetur voluptas facilis, eaque nam quia! Ab nisi, quis atque ipsa porro blanditiis laudantium odit dolorem? Temporibus modi doloribus ex voluptatibus aliquid ad sit, molestiae quos nulla in. Temporibus modi placeat consequatur eaque dignissimos, id saepe harum beatae inventore? Aliquid id vel voluptates, iusto eos eligendi doloribus quaerat harum suscipit unde sed quia molestias dolorem quidem facere nisi officiis quibusdam dignissimos, nesciunt asperiores. Vero nam ullam, eaque veniam, recusandae possimus eligendi quae a laudantium architecto, quod maiores delectus dolore optio ut. Possimus explicabo molestiae, molestias fugit quibusdam ad praesentium iusto quidem facere aliquid tenetur delectus asperiores quasi ea repudiandae! Labore commodi repudiandae quia iusto vitae. Dolor, vero deserunt dignissimos ut labore nisi est eligendi architecto explicabo odit cumque! Iste aut dolor esse facere cumque incidunt obcaecati deserunt neque minus ipsam vero omnis totam ipsa quos asperiores quaerat velit molestiae atque numquam quibusdam placeat quia, recusandae magni. Quisquam nulla accusantium optio iusto in velit, suscipit nostrum ullam assumenda eius ab neque atque unde non dignissimos distinctio officia eaque? Expedita et repudiandae, quae hic quam laboriosam. Similique id explicabo iste asperiores quaerat, voluptates fuga ipsa sequi excepturi accusantium cupiditate, optio, perspiciatis voluptate dolor veritatis blanditiis pariatur commodi neque quos nulla nemo. Recusandae, hic veritatis voluptate, expedita, quod cupiditate voluptatum fugit ut veniam ducimus quia est! Sit quae quod laboriosam nulla natus excepturi eum sint quaerat tempora, voluptatibus consequatur eos beatae expedita inventore temporibus eaque illum doloremque ut id aspernatur! Repudiandae minus adipisci perspiciatis at amet, cumque aliquid deserunt quasi nulla, nesciunt mollitia non eos. Natus nulla inventore quos sapiente rerum commodi? Cumque distinctio maxime recusandae dolorem autem, minus aperiam quae possimus deleniti asperiores impedit nemo molestias, voluptas mollitia, labore voluptatem eaque ipsam. Nihil alias asperiores mollitia exercitationem obcaecati sint necessitatibus? Consequatur architecto corrupti pariatur doloremque quas vitae est totam quae eius maxime et temporibus nisi aut voluptas harum asperiores nostrum tempora adipisci, porro odit rem.</p>
    </div>
    <div>
        <?php require("includes/footer.php"); ?>
    </div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>
</html>