<?php
    require("includes/connection.php");
    if (!(isset($_SESSION['loggedin']) && ($_SESSION['loggedin']))) {
        header("location: /ecorce/signin.php");
    }
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" 
        crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" 
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" 
        crossorigin="anonymous" />
    <style>
        #maincontainer{
            min-height: 70vh;
        }
    </style>
    <title>ECORCE - Cart</title>
</head>

<body class="bg-aids">
    <?php include 'includes/header.php';?>

               <div class="container-fluid d-flex row my-4 me-0" id="maincontainer">
               <div class="col-sm-8">
                    <table class="table text-center align-middle bg-light table-hover border border-warning rounded">

                       
                        <?php
                        $sno = 0;
                        $sum = 0;
                        $user_id = $_SESSION['id'];
                        $query = "SELECT electronics_cat.elect_category_price AS 
                        Price, electronics_cat.elect_category_id, electronics_cat.elect_category_name AS Name FROM cart 
                        JOIN electronics_cat ON cart.elect_category_id = electronics_cat.elect_category_id WHERE
                         cart.user_id='$user_id' and status='Added to cart'";
                        $result = mysqli_query($conn, $query);
                        if (mysqli_num_rows($result) >= 1) {
                            ?>
                            <thead>
                                <tr>
                                    <th scope="col" class="text-warning">Sr#</th>
                                    <th scope="col" class="text-warning">Image</th>
                                    <th scope="col" class="text-warning">Item Name</th>
                                    <th scope="col" class="text-warning">Price</th>
                                    <th scope="col" class="text-warning">Remove</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php
                                    
                                while ($row = mysqli_fetch_array($result)) {
                                    $sno = $sno + 1;
                                    $sum+= $row["Price"];
                                    $id="";
                                    $id .= $row["elect_category_id"] . ",";
                                    echo "<tr>
                                              <th scope='col'>" . $sno . "</th>
                                              <td><img src='images/" . $row["elect_category_id"] .".jpg' width='50px' height='43px' class='' alt='...'></td>
                                              <td class='fw-bold text-success'>" . $row["Name"] . "</td>
                                              <td class='fw-bold text-secondary'>" . $row["Price"] . " PKR/-</td>
                                              <td><button class='btn btn-sm btn-danger'><a href='cartRemove.php?id={$row['elect_category_id']}' 
                                              class='remove_item_link text-light text-decoration-none'> Remove </a></button></td>
                                          </tr>";
                                }
                                ?>
                            </tbody>
                            <?php
                        } else {
                            echo "<center><h2><br>Add items to the cart first!</h2><p><a href='index.php'>click here</a> to explore products</p></center>";
                        }
                        ?>
                    </table>
                </div>
             
             <div class="text-center col-sm-4">
                 <?php
                    
                    
                    $id = rtrim($id, ",");

                                    echo'<div class="p-5 container border border-warning bg-white rounded">
                                    <h4 class="">Price Details:</h4>
                                    <table class="table table-borderless border-top border-bottom">
                                        <tbody>
                                            <tr>
                                                <th class="text-start">Total Price('. $sno .' items)</th>
                                                <td>' . $sum . '</td>
                                            </tr>
                                            <tr class="border-bottom">
                                                <th class="text-start">Delivery Charges</th>
                                                <td class="text-success">Free</td>
                                            </tr>
                                            <tr>
                                                <th class="text-start">Amount Payable</th>
                                                <td>' . $sum . ' pkr/-</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <a href="success.php?itemsid='.$id.'"class="mt-4 btn btn-sm btn-warning">Confirm Order</a></td>
                                    </div>';
                 ?>
                </div>
               </div>

    <?php include 'includes/footer.php';?>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>

</html>