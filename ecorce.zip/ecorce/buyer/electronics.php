<?php
    require('includes/connection.php');
?>

<div class="p-2 bg-aids py-5">    
        <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 text-center g-4 mx-5 py-5 ">
        <?php 
         $sql = "SELECT * FROM `electronics_cat`"; 
         $result = $conn->query($sql);
         while($row = mysqli_fetch_assoc($result)){
          $id = $row['elect_category_id'];
          $cat = $row['elect_category_name'];
          $price = $row['elect_category_price'];
          echo '<div class="col my-4">
          <div class="card h-100 shadow-lg border border-warning mx-2">';
            
             echo '<a href="commentlist.php?electcatid=' 
             . $id . '"><img src="images/' . $id .'.jpg" class="card-img-top" alt="..."></a>
              <div class="card-body">
              <h6 class="card-title mt-4"><a class="text-success text-decoration-none fw-bold" href="commentlist.php?electcatid=' 
              . $id . '">' . $cat . '</a></h6>
              <p class="card-text mt-3 fw-bold text-secondary">Rs.'. $price .'/-</p>';
              ?>
              <?php
              if (isset($_SESSION['loggedin']) && ($_SESSION['loggedin'])) {
              $user_id = $_SESSION['id'];
              $query = "SELECT * FROM cart WHERE elect_category_id='$id' AND user_id ='$user_id' and status='Added to cart'";
              $result2 = mysqli_query($conn, $query);
              if (mysqli_num_rows($result2) >= 1) {
                echo '<button class="card-text btn btn-sm btn-success text-light fw-bold py-2" name="cart">Added 
                <i class="fas fa-shopping-cart"></i></button>
                </div>
                </div>
                </div>';
              } else {
                echo '<button class="card-text btn btn-sm btn-warning py-2" name="cart">
                <a href="cartAdd.php?id=' . $id .'" class="text-decoration-none text-success fw-bold">
                Add to cart <i class="fas fa-shopping-cart"></i></a></button>
                </div>
                </div>
                </div>';
              }
            } else {
                echo '<button class="card-text btn btn-sm btn-warning text-success fw-bold py-2" name="cart">Add to cart 
                <i class="fas fa-shopping-cart"></i></button>
                </div>
                </div>
                </div>';
              }
            }
         ?>
        </div>
    </div>