<?php
    require("includes/connection.php");
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" 
        rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" 
        crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/breakpoints.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" 
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" 
        crossorigin="anonymous" />
    <style>
        #maincontainer{
            min-height: 100vh;
        }
    </style>
    <title>ECORCE - Search</title>
</head>

<body class="bg-aids">
    <!-- <h1>Hello</h1>     -->
    <?php include 'includes/header.php';?>

    <!-- Search Results -->
  <div class="container my-3" id="maincontainer">
        <h1 class="py-3">Search results for <em>"<?php echo $_GET['search']?>"</em></h1>
        <hr />

        <?php  
        $noresults = true;
        $query = $_GET["search"];
        $sql = "SELECT * FROM `electronics_cat` WHERE MATCH(`elect_category_name`, `elect_category_desc`) AGAINST ('$query')"; 
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $title = $row['elect_category_name'];
            $desc = $row['elect_category_desc']; 
            $price = $row['elect_category_price']; 
            $cat_id= $row['elect_category_id'];
            $url = "commentlist.php?electcatid=". $cat_id;
            $noresults = false;

            // Display the search result
            echo '<div class="result d-flex my-5 bg-aid rounded p-4 border border-secondary shadow-lg">
            <img src="images/' . $cat_id . '.jpg" width="150px" class="me-5 img-fluid rounded-start" alt="...">
            <div>
            <h3><a href="'. $url. '" class="text-success">'. $title. '</a> </h3>
            <p class="fw-bold text-secondary">RS.' . $price . '/-</p>
            <p>' . substr($desc, 0, 300). '...</p>
            </div></div>'; 
            }
        if ($noresults){
            echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="display-4">No Results Found</p>
                        <p class="lead"> Suggestions: <ul>
                                <li>Make sure that all words are spelled correctly.</li>
                                <li>Try different keywords.</li>
                                <li>Try more general keywords. </li></ul>
                        </p>
                    </div>
                 </div>';
        }        
    ?>
  </div>

    <?php include 'includes/footer.php';?>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>

</html>